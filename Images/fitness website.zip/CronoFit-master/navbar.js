const navbar=()=>{

    return `
    <div >
    <div id="navbarimage"> <img class="site-logo" src="cronofit.png" alt=""></div>
     
    </div>
    <div id="nav-c">
  <p> <a href=" ">Products</p></a> 
  <p><a href="support.html">Support</p></a>
  <p><a href="blog.html">Blog</p></a>
  <p><a href=" ">Forums</p></a>
  <p><a href="about.html">About</p></a>
  <a href="login.html"><button>Log In</button></a>




    </div>
`

}

export { navbar }