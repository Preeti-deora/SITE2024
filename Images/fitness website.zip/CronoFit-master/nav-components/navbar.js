const navbar=()=>{

    return `
    <div>
    <<img class="site-logo" src="cronofit.png" alt="">
      
    </div>
    <div id="nav-c">
  <p> <a href="">Products</p></a> 
  <p><a href=" ">Support</p></a>
  <p><a href=" ">Blog</p></a>
  <p><a href=" ">Forums</p></a>
  <p><a href=" ">About</p></a>
  <button>Log In</button>




    </div>
`

}

export { navbar }