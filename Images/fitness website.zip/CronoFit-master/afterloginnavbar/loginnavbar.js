function navbar(){


    return `
    <div id="logo">
            <img src="cronofit.png" alt="" id="icon">
        </div>
        <div id="navArea">
            <div><a href="diary.html" style="text-decoration:none;color:rgb(225, 95, 44)">Diary</a></div>
            <div>Trends</div>
            <div>Foods</div>
            <div>Settings</div>
            <div><a href="plans.html" style="text-decoration:none;color:rgb(225, 95, 44)">Plans</a></div>
            <div><a href="help.html" style="text-decoration:none;color:rgb(225, 95, 44)">Help</a></div>
        </div>
    `
}

export { navbar }