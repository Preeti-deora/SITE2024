function footer(){
    return ` <div id="footerbtns">
    <div class="button" id="blog">Blog</div>
    <div class="orange-dot">
     <div class="dot"></div>
    </div>
    <div class="button" >Forums</div>
    <div class="orange-dot">
     <div class="dot">

     </div>
    </div>
    <div class="button" >Privacy</div>
    <div class="orange-dot">

     <div class="dot">

     </div>
    </div>
    <div class="button" >Terms</div>
    <div class="orange-dot">
     <div class="dot"></div>
    </div>
    <div class="button" >Affiliates</div>
    <div class="orange-dot">
     <div class="dot"></div>
    </div>
    <div class="button" >Jobs</div>
 </div>


 <div id="mainfooter">
    <div id="gplay">
     <div id="ios">
         <img src="https://cdn1.cronometer.com/logos/app-store.png" alt="">
     </div>
     <div id="android">
         <img src="https://cdn1.cronometer.com/logos/google-play.png" alt="">
     </div>
    </div>
    <div id="footerlogo">
    <img src="cronofit.png" alt="" id="footericon">
    </div>
    <div id="socialmedia">
     <div>
         <a href="https://www.facebook.com/" target="_blank">
             <img src="https://cdn1.cronometer.com/logos/icon-facebook-white.png" alt="" class="link">
         </a>
         
     </div>
     <div>
         <a href="https://twitter.com/" target="_blank">
             <img src="https://cdn1.cronometer.com/logos/icon-twitter-white.png" alt=""  class="link">
         </a>
     </div>
     <div>
         <a href="https://www.instagram.com/" target="_blank">
             <img src="https://cdn1.cronometer.com/logos/icon-instagram-white.png" alt="" class="link">
         </a>
     </div>
     <div>
         <a href="https://www.youtube.com/" target="_blank">
             <img src="https://cdn1.cronometer.com/logos/icon-youtube-white.png" alt="" class="link">
         </a>
     </div>
    </div>
 </div>`
}

function support(){
    return `<button>
    <div id="supportcircle">
        &#63;
    </div>
    <span>Support</span>
   </button>`
}

export { footer,support }