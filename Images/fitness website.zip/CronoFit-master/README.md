# spotless-thumb-400
This project is about a website through which we can Track our diet, exercise, and health data

This is a collaborative project which was made in the duration of 4 days.I worked as the Project lead.

## Features

#### 1. Homapage, Support page, Blogs, Login, Signup and Profile page.
#### 2. Track daily calorie, protein, energy and fat intake.
#### 3. Access all the features of the website by logging in the website.

## Tech Stack

#### 1. HTMl
#### 2. CSS
#### 3. JavaScript

## Tools used

#### 1. VS Code

#### 2. Netlify

#### 3. Git & GitHub

## Images Of Different pages
![image](https://user-images.githubusercontent.com/108731705/215064370-c92e525d-347f-498d-ba74-17f57be967f9.png)
![image](https://user-images.githubusercontent.com/108731705/215065591-145ff868-291e-4595-84a0-ef8d557ee20c.png)
![image](https://user-images.githubusercontent.com/108731705/215066021-bde65392-369b-46fc-a6e3-2aa81dcf942d.png)
![image](https://user-images.githubusercontent.com/108731705/215066075-173ef418-91d9-4f83-836b-a5f3b7fe692f.png)
