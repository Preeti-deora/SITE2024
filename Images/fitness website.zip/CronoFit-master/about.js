import { navbar } from "./navbar.js";
let nav_bar=document.getElementById("navbar");

nav_bar.innerHTML=navbar();