let request=document.querySelector("#request");
request.addEventListener("click",function(e){
    window.location="support_page\submitrequest\submit.html"
})

