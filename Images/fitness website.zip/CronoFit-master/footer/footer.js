const footer = () => {
    return `
    
<div id="logo">
<div>
    <img src="https://cdn1.cronometer.com/2021/landing/social_instagram-icon.png" alt="">
</div>
<div>
    <img src="https://cdn1.cronometer.com/2021/landing/social_facebook-icon.png" alt="">
</div>
<div>
    <img src="https://cdn1.cronometer.com/2021/landing/social_twitter-icon.png" alt="">
</div>
<div>
    <img src="https://cdn1.cronometer.com/2021/landing/social_youtube-icon.png" alt="">
</div>
</div>

<div id="download">

<div>
    <img src="https://cdn1.cronometer.com/2021/landing/ios-icon.svg" alt="">

</div>
<div><img src=" https://cdn1.cronometer.com/2021/landing/android-icon.svg" alt="">
</div>
</div>

<hr style="width: 90%;height:0.1px;background-color:white">

<div id="footer-sections">
<div>
    <img id="footer-logo" height="70px" width="70%" src="cronofit.png" alt="">
</div>
<div>
    <h2>Cronometer</h2>
    <p>For Individuals</p>
    <p>For Proffesionals</p>
    <p>Privacy</p>
    <p>Terms</p>
</div>
<div>
    <h2>The Company</h2>
    <p>Abot Us</p>
    <p>Crono Blog</p>
    <p>Cronon Forums</p>
    <p>Jobs</p
        >
        <p>Support</p>
</div>
<div>
    <h2>Partners & Affiliates</h2>
    <p>Affiliate Program</p>
    <p>Media Kit</p>
</div>
</div>
<h2 style="width:18% ;margin:auto;font-weight: 300;font-size: 21px;text-align: center;padding-bottom: 10px;">Copyright © 2011-2022
All rights reserved</h1>
  `
}

export { footer }