<div class="container-fluid bg-dark text-light">
    <p class="text-center mb-0" > Copyright RAKSforum2023 | All Rights Reserved</p>
</div>